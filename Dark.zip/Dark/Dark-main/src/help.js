const help = (prefix) => {
	return `
       • ──── ✾ ──── •
       *FIGURINHAS*【✔】
       • ──── ✾ ──── •
      
➸ Comando : *${prefix}sticker* ou *${prefix}stiker*
➸ útil em : converter imagem/gif/vídeo em adesivo
➸ uso : responder imagem/gif/video ou enviar imagem/gif/video com legenda\n

➸ Comando : *${prefix}sticker nobg* ou *${prefix}stiker nobg*
➸ útil em : converter imagem em adesivo removendo o fundo
➸ uso : responder imagem ou enviar imagem com legenda/n

➸ Comando : *${prefix}toimg*
➸ útil em : converter adesivo em imagem
➸ uso : adesivo de resposta\n

➸ Comando : *${prefix}tsticker* ou *${prefix}tstiker*
➸ útil em : converter texto em adesivo
➸ uso : *${prefix}tsticker seu texto aqui*\n

➸ Comando : *${prefix}gtts*
➸ útil em : converter texto em fala/áudio
➸ uso : *${prefix}gtts [cc] [text]*\nexemplo : *${prefix}gtts ja On2-chan*\n

➸ Comando : *${prefix}ocr*
➸ útil em : pegar o texto da foto e lhe enviar
➸ uso : responder imagem ou enviar mensagem com legenda\n`
}

exports.help = help






